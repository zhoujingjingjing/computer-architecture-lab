########################################################################
#			Sample Script (v0.1)
########################################################################
#
# Author: Zhenyu Ye
# E-mail: z.ye@student.tue.nl
# Date: Dec. 15, 2008
#
# Description:
# This is a simple script used as an example.
# If you want to change more parameters at a time, you may need nested
# loops or conditional statements.
# Many tutorials on Linux shell programming are freely available online.
#
########################################################################

########################################################################
#
# Set the variable below according to your own working environment:
#
# WATTCH_PATH: the path containing Wattch sim-outorder binary
# BIN_PATH: the path containing the binary program to be simulated.
# BIN_NAME: the name of the binary to be simulated.
#
########################################################################

WATTCH_PATH=$HOME/SimpleScalar/sim-wattch-1.02d
BIN_PATH=.
BIN_NAME="test-fmath"

########################################################################
#
# Body of the script:
#
# In this example, I replace a paramter (e.g. -ruu:size), which I want 
# to tune, with a special variable name (e.g. RUU_SIZE_PARA). 
#
# In each iteration of the for loop, the command "sed" replaces
# "RUU_SIZE_PARA" in file "ruu_size_null.cfg" with "2", "4" and "8",
# and generate a new config file "ruu_size_2(/4/8).cfg".
#
# In each iteration, sim-outorder run with "ruu_size_2(/4/8).cfg".
# The simulation output is dumped to file:
# test-fmath.simout_ruu_size_2(/4/8)
# The program output is dumped to file:
# test-fmath.progout_ruu_size_2(/4/8)
# Config file "ruu_size_2(/4/8).cfg" is removed before next iteration.
# To see the config file used in each iteration, comment this line:
# rm "ruu_size_$i.cfg"
#
########################################################################

for i in 2 4 8
do
	echo "-ruu:size $i"
	sed '/RUU_SIZE_PARA/s//'$i'/g' ruu_size_null.cfg > "ruu_size_$i.cfg"
	$WATTCH_PATH/sim-outorder -config "ruu_size_$i.cfg" $BIN_PATH/$BIN_NAME > "$BIN_NAME.progout_ruu_size_$i" 2> "$BIN_NAME.simout_ruu_size_$i"
	rm "ruu_size_$i.cfg"
done
